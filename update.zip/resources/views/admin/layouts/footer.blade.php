
<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
</aside>
<!-- /.control-sidebar -->

<!-- Main Footer -->
<footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-sm-none d-md-block">
       برنامه دیگر
    </div>
    <!-- Default to the left -->
    <strong>CopyLeft &copy; 2020 <a href="">محمد حسین وفق </a>.</strong>
</footer>
