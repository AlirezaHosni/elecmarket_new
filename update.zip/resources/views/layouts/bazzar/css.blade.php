<!-- Font Awesome Icons -->
<link rel="stylesheet" href="{{ asset('assets/plugins/font-awesome/css/font-awesome.min.css') }}">
<!-- Theme style -->
<link rel="stylesheet" href="{{ asset('assets/css/adminlte.min.css') }}">
<!-- Google Font: Source Sans Pro -->
<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">

<!-- bootstrap rtl -->
<link rel="stylesheet" href="{{ asset('assets/css/bootstrap-rtl.min.css') }}">
<!-- template rtl version -->
<link rel="stylesheet" href="{{ asset('assets/css/custom-style.css') }}">
<link rel="stylesheet" href="{{ asset('assets/css/sweetalert.css') }}">
