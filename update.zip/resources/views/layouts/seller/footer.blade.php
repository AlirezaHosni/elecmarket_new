
<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
</aside>
<!-- /.control-sidebar -->

<!-- Main Footer -->
<footer class="main-footer">
    <!-- To the right -->

    <!-- Default to the left -->
    <strong>CopyLeft &copy; 2020 <a href="">محمد حسین وفق </a>.</strong>
</footer>
