<div class="sbn_app_wrapper">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="sbn_app">
                    <div class="sbn_app_content">
                        <h3>دانلود اپلیکیشن </h3>
                        <p></p>
                    </div>
                    <div class="sbn_app_buttons">
                        <ul class="sbn_app_buttons_list">
                            <li>
                                <a href="">
                                    <img src="{{ asset('assets/front/images/sbn_app_apple.png') }}" alt="">
                                </a>
                            </li>
                            <li>
                                <a href="">
                                    <img src="{{ asset('assets/front/images/sbn_app_google.pn') }}g" alt="">
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
