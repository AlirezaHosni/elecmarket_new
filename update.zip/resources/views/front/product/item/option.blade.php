
<div id="product__option_mobile" class="c-product__options" style="display: none; text-align: center;
    margin-right: 25%;">
    <ul class="c-product__actions">
        <li>
            <button class="c-btn-option c-btn-option--wishlist fa fa-heart "></button>
        </li>
        <li>
            <button class="c-btn-option c-btn-option--share fa fa-share-square"></button>
        </li>
        <li>
            <button class="c-btn-option c-btn-option--chart fa fa-bar-chart"></button>
        </li>
        <li>
            <button class="c-btn-option c-btn-option--notification fa fa-inbox"></button>
        </li>
    </ul>
</div>
